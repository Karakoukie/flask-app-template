from hello import app

application = app